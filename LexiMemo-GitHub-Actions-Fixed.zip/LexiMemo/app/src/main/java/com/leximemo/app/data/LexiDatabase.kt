package com.leximemo.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [WordEntity::class, ReviewEventEntity::class, ReviewHistoryEntity::class, DailyActivityEntity::class],
    version = 1,
    exportSchema = true
)
abstract class LexiDatabase : RoomDatabase() {
    abstract fun dao(): LexiDao
}
