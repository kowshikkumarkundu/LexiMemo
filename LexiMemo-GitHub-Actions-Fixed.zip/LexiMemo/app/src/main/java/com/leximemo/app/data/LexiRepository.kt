package com.leximemo.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class LexiRepository(private val db: LexiDatabase) {
    private val dao = db.dao()

    fun words(): Flow<List<WordEntity>> = dao.observeWords()
    fun todayWords(): Flow<List<WordEntity>> = dao.observeWordsAddedOn(LocalDate.now().toString())
    fun favorites(): Flow<List<WordEntity>> = dao.observeFavorites()
    fun collection(status: String): Flow<List<WordEntity>> = dao.observeByStatus(status)

    suspend fun addWord(
        word: String, englishMeaning: String, banglaMeaning: String, sentence1: String,
        sentence2: String = "", partOfSpeech: String = "", synonyms: String = "",
        antonyms: String = "", imageUri: String = ""
    ) {
        val today = LocalDate.now()
        db.withTransaction {
            val id = dao.insertWord(
                WordEntity(
                    word = word.trim(),
                    englishMeaning = englishMeaning.trim(),
                    banglaMeaning = banglaMeaning.trim(),
                    sentence1 = sentence1.trim(),
                    sentence2 = sentence2.trim(),
                    partOfSpeech = partOfSpeech.trim(),
                    synonyms = synonyms.trim(),
                    antonyms = antonyms.trim(),
                    imageUri = imageUri,
                    addedDate = today.toString()
                )
            )
            val intervals = listOf(1, 3, 7, 15, 30)
            dao.insertReviewEvents(intervals.map { offset ->
                ReviewEventEntity(wordId = id, intervalDay = offset, dueDate = today.plusDays(offset.toLong()).toString())
            })
            val activity = dao.getDailyActivity(today.toString())
            dao.upsertDailyActivity(DailyActivityEntity(today.toString(), (activity?.wordsAdded ?: 0) + 1))
        }
    }

    suspend fun dueWords(): List<Pair<WordEntity, List<ReviewEventEntity>>> {
        val today = LocalDate.now().toString()
        val dueEvents = dao.getDueEvents(today)
        return dueEvents.groupBy { it.wordId }.mapNotNull { (wordId, events) ->
            val word = dao.getWord(wordId) ?: return@mapNotNull null
            word to events
        }
    }

    suspend fun rateRevision(word: WordEntity, rating: String) {
        val today = LocalDate.now().toString()
        db.withTransaction {
            val due = dao.getPendingDueEventsForWord(word.id, today)
            if (due.isNotEmpty()) {
                dao.updateReviewEvents(due.map { it.copy(completed = true, completedAt = today) })
                dao.insertHistory(
                    ReviewHistoryEntity(
                        wordId = word.id,
                        rating = rating,
                        reviewedAt = today,
                        dueEventIds = due.joinToString(",") { it.id.toString() }
                    )
                )
                dao.updateWord(word.copy(latestStatus = rating))
            }
        }
    }

    suspend fun setFavorite(wordId: Long, favorite: Boolean) = dao.setFavorite(wordId, favorite)
    suspend fun activity(date: String = LocalDate.now().toString()) = dao.getDailyActivity(date)
    suspend fun allActivity() = dao.getAllDailyActivity()
}
