package com.leximemo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.room.Room
import com.leximemo.app.data.LexiDatabase
import com.leximemo.app.data.LexiRepository
import com.leximemo.app.ui.LexiApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = Room.databaseBuilder(applicationContext, LexiDatabase::class.java, "leximemo.db").build()
        val repository = LexiRepository(database)
        setContent { LexiApp(repository) }
    }
}
