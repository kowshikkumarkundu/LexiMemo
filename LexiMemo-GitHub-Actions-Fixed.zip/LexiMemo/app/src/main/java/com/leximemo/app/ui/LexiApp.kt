package com.leximemo.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leximemo.app.data.LexiRepository
import com.leximemo.app.data.WordEntity
import kotlinx.coroutines.launch

private val Purple = Color(0xFF7655C8)
private val Ink = Color(0xFF202033)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LexiApp(repo: LexiRepository) {
    var page by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<WordEntity?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showImage by remember { mutableStateOf<String?>(null) }
    val words by repo.words().collectAsStateWithLifecycle(initialValue = emptyList())
    val todayWords by repo.todayWords().collectAsStateWithLifecycle(initialValue = emptyList())
    val favorites by repo.favorites().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple, onPrimary = Color.White,
            background = Color(0xFFF7F7FB), surface = Color.White,
            onSurface = Ink, secondary = Color(0xFF8A79B8)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7F7FB),
            topBar = {
                TopAppBar(
                    title = { Text("LexiMemo", style = MaterialTheme.typography.titleLarge) },
                    navigationIcon = {
                        IconButton(onClick = { page = "Home" }) { Icon(Icons.Default.MenuBook, null) }
                    },
                    actions = {
                        IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add word") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF7F7FB))
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Practice", "Revision", "Dictionary").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item; selected = null },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Home" -> Icons.Default.Home
                                        "Practice" -> Icons.Default.Style
                                        "Revision" -> Icons.Default.Replay
                                        else -> Icons.Default.MenuBook
                                    }, null
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                when (page) {
                    "Home" -> HomeScreen(words.size, todayWords.size, onAdd = { showAdd = true }, onGo = { page = it })
                    "Practice" -> WordListScreen("Today's Words", todayWords, onSelect = { selected = it }, onFavorite = { w -> scope.launch { repo.setFavorite(w.id, !w.isFavorite) } })
                    "Dictionary" -> WordListScreen("Dictionary", words, onSelect = { selected = it }, onFavorite = { w -> scope.launch { repo.setFavorite(w.id, !w.isFavorite) } })
                    "Revision" -> RevisionScreen(repo)
                }
            }
        }

        if (showAdd) AddWordDialog(
            onDismiss = { showAdd = false },
            onSave = { fields ->
                scope.launch { repo.addWord(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8]) }
                showAdd = false
            }
        )
        selected?.let { word ->
            WordPracticeDialog(word, onDismiss = { selected = null }, onImage = { showImage = it })
        }
        showImage?.let { uri ->
            AlertDialog(
                onDismissRequest = { showImage = null },
                confirmButton = { TextButton(onClick = { showImage = null }) { Text("Close") } },
                text = { Text("Image preview: $uri") },
                title = { Text("Image") }
            )
        }
    }
}

@Composable
private fun HomeScreen(total: Int, today: Int, onAdd: () -> Unit, onGo: (String) -> Unit) {
    Spacer(Modifier.height(12.dp))
    Text("Your learning space", style = MaterialTheme.typography.headlineSmall)
    Text("Small steps, lasting memory.", color = Color.Gray)
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard("Today's words", today.toString(), Modifier.weight(1f))
        StatCard("Dictionary", total.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(18.dp)) {
            Text("Daily target", style = MaterialTheme.typography.titleMedium)
            Text("$today / 5 words", color = Purple, style = MaterialTheme.typography.headlineMedium)
            LinearProgressIndicator(progress = { (today / 5f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Purple)
        }
    }
    Spacer(Modifier.height(14.dp))
    Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
        Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add New Word")
    }
    OutlinedButton(onClick = { onGo("Practice") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("Practice Today's Words") }
    OutlinedButton(onClick = { onGo("Revision") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("Start Today's Revision") }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Purple)
        }
    }
}

@Composable
private fun WordListScreen(title: String, words: List<WordEntity>, onSelect: (WordEntity) -> Unit, onFavorite: (WordEntity) -> Unit) {
    Spacer(Modifier.height(12.dp))
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(8.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(words, key = { it.id }) { word ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelect(word) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(word.word, style = MaterialTheme.typography.titleMedium)
                        Text(word.banglaMeaning, color = Color.Gray)
                    }
                    IconButton(onClick = { onFavorite(word) }) {
                        Icon(if (word.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Purple)
                    }
                }
            }
        }
    }
}

@Composable
private fun WordPracticeDialog(word: WordEntity, onDismiss: () -> Unit, onImage: (String) -> Unit) {
    var hints by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text(word.word, style = MaterialTheme.typography.headlineMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { hints = !hints }) { Text(if (hints) "Hide Hints" else "Hints") }
                    Button(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
                }
                if (hints) {
                    if (word.imageUri.isNotBlank()) {
                        Text("Image attached — tap to view", color = Purple, modifier = Modifier.clickable { onImage(word.imageUri) })
                    }
                    Text(word.sentence1)
                    if (word.sentence2.isNotBlank()) Text(word.sentence2)
                }
                if (show) {
                    Text("English meaning: ${word.englishMeaning}")
                    Text("বাংলা অর্থ: ${word.banglaMeaning}")
                    if (word.partOfSpeech.isNotBlank()) Text("Part of speech: ${word.partOfSpeech}")
                    if (word.synonyms.isNotBlank()) Text("Synonyms: ${word.synonyms}")
                    if (word.antonyms.isNotBlank()) Text("Antonyms: ${word.antonyms}")
                }
            }
        }
    )
}

@Composable
private fun RevisionScreen(repo: LexiRepository) {
    var due by remember { mutableStateOf<List<Pair<WordEntity, List<com.leximemo.app.data.ReviewEventEntity>>>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        due = repo.dueWords()
        loading = false
    }
    Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Today's Revision", style = MaterialTheme.typography.headlineSmall)
        when {
            loading -> CircularProgressIndicator()
            due.isEmpty() -> Text("You're all caught up. No pending revisions today.", color = Color.Gray)
            else -> {
                val current = due.getOrNull(index.coerceIn(0, due.lastIndex))
                current?.let { (word, events) ->
                    Text("Word ${index + 1} of ${due.size}", color = Color.Gray)
                    LinearProgressIndicator(progress = { (index + 1f) / due.size }, modifier = Modifier.fillMaxWidth())
                    WordRevisionCard(word)
                    Text("Pending reviews: ${events.size}", color = Color.Gray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Memorized", "Hint Needed", "Forgot").forEach { rating ->
                            Button(
                                onClick = {
                                    scope.launch {
                                        repo.rateRevision(word, rating)
                                        due = repo.dueWords()
                                        index = 0
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                            ) { Text(rating, style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        IconButton(onClick = { index = (index - 1).coerceAtLeast(0) }) { Icon(Icons.Default.ArrowBack, "Previous") }
                        IconButton(onClick = { index = (index + 1).coerceAtMost(due.lastIndex) }) { Icon(Icons.Default.ArrowForward, "Next") }
                    }
                }
            }
        }
    }
}

@Composable
private fun WordRevisionCard(word: WordEntity) {
    var hints by remember { mutableStateOf(false) }
    var show by remember { mutableStateOf(false) }
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(word.word, style = MaterialTheme.typography.headlineLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { hints = !hints }) { Text("Hints") }
                Button(onClick = { show = !show }) { Text("Show") }
            }
            if (hints) {
                Text(word.sentence1, color = Color.Gray)
                if (word.sentence2.isNotBlank()) Text(word.sentence2, color = Color.Gray)
            }
            if (show) {
                Text(word.englishMeaning)
                Text(word.banglaMeaning, color = Purple)
            }
        }
    }
}

@Composable
private fun AddWordDialog(onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    val labels = listOf("English Word *", "English Meaning *", "বাংলা অর্থ *", "Sentence 1 *", "Sentence 2", "Part of Speech", "Synonyms", "Antonyms", "Image URI (optional)")
    val values = remember { mutableStateListOf("", "", "", "", "", "", "", "", "") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        values[8] = uri?.toString() ?: ""
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Word") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.heightIn(max = 480.dp)) {
                items(labels.size) { i ->
                    if (i == 8) {
                        OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp))
                            Text(if (values[8].isBlank()) "Choose Image (Optional)" else "Image selected")
                        }
                    } else {
                        OutlinedTextField(
                            value = values[i], onValueChange = { values[i] = it },
                            label = { Text(labels[i]) }, modifier = Modifier.fillMaxWidth(),
                            singleLine = i != 3 && i != 4
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = values.take(4).all { it.isNotBlank() },
                onClick = { onSave(values.toList()) }
            ) { Text("Save Word") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
