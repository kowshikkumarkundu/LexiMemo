package com.leximemo.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LexiDao {
    @Query("SELECT * FROM words ORDER BY addedDate DESC, id DESC")
    fun observeWords(): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE id = :id")
    suspend fun getWord(id: Long): WordEntity?

    @Insert
    suspend fun insertWord(word: WordEntity): Long

    @Update
    suspend fun updateWord(word: WordEntity)

    @Query("UPDATE words SET isFavorite = :favorite WHERE id = :wordId")
    suspend fun setFavorite(wordId: Long, favorite: Boolean)

    @Query("SELECT * FROM words WHERE addedDate = :date ORDER BY id DESC")
    fun observeWordsAddedOn(date: String): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE latestStatus = :status ORDER BY word COLLATE NOCASE")
    fun observeByStatus(status: String): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE isFavorite = 1 ORDER BY word COLLATE NOCASE")
    fun observeFavorites(): Flow<List<WordEntity>>

    @Query("SELECT * FROM review_events WHERE completed = 0 AND dueDate <= :today ORDER BY dueDate, id")
    suspend fun getDueEvents(today: String): List<ReviewEventEntity>

    @Query("SELECT * FROM review_events WHERE wordId = :wordId AND completed = 0 AND dueDate <= :today")
    suspend fun getPendingDueEventsForWord(wordId: Long, today: String): List<ReviewEventEntity>

    @Insert
    suspend fun insertReviewEvents(events: List<ReviewEventEntity>)

    @Update
    suspend fun updateReviewEvents(events: List<ReviewEventEntity>)

    @Insert
    suspend fun insertHistory(history: ReviewHistoryEntity)

    @Query("SELECT * FROM daily_activity WHERE date = :date")
    suspend fun getDailyActivity(date: String): DailyActivityEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyActivity(activity: DailyActivityEntity)

    @Query("SELECT * FROM daily_activity ORDER BY date")
    suspend fun getAllDailyActivity(): List<DailyActivityEntity>

    @Query("SELECT * FROM review_events ORDER BY id")
    suspend fun getAllReviewEvents(): List<ReviewEventEntity>

    @Query("SELECT * FROM review_history ORDER BY id")
    suspend fun getAllReviewHistory(): List<ReviewHistoryEntity>
}
