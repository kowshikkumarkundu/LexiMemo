package com.leximemo.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "words")
data class WordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val word: String,
    val englishMeaning: String,
    val banglaMeaning: String,
    val sentence1: String,
    val sentence2: String = "",
    val partOfSpeech: String = "",
    val synonyms: String = "",
    val antonyms: String = "",
    val imageUri: String = "",
    val addedDate: String,
    val isFavorite: Boolean = false,
    val latestStatus: String = ""
)

@Entity(
    tableName = "review_events",
    indices = [androidx.room.Index(value = ["wordId", "dueDate", "intervalDay"], unique = true)]
)
data class ReviewEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: Long,
    val intervalDay: Int,
    val dueDate: String,
    val completed: Boolean = false,
    val completedAt: String = ""
)

@Entity(tableName = "review_history")
data class ReviewHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: Long,
    val rating: String,
    val reviewedAt: String,
    val dueEventIds: String
)

@Entity(tableName = "daily_activity")
data class DailyActivityEntity(
    @PrimaryKey val date: String,
    val wordsAdded: Int
)
