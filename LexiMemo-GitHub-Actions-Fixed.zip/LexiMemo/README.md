# LexiMemo (Starter Build)

Personal offline English vocabulary memorization app.

## Requirements
- Android Studio
- JDK 17
- Android SDK 35

## Open
1. Extract this ZIP.
2. Open the `LexiMemo` folder in Android Studio.
3. Allow Gradle sync.
4. Run on an Android device or emulator.

## Current implementation
- Light-theme Compose foundation.
- Local Room database.
- Add vocabulary with required and optional fields.
- Daily word tracking.
- Per-word fixed Day 1, 3, 7, 15, 30 review events.
- Combined due revision list.
- Memorized / Hint Needed / Forgot ratings.
- Today's practice and dictionary lists.
- Favorite toggle.
- Hints and Show flashcard actions.

## Important
This is the first implementation milestone, not the final release. Backup/restore with embedded image files, full image viewer, random test collections, configurable daily target, streak display, and UI polish are next implementation tasks. Image picker currently stores the selected URI string; persistent URI permission and full backup packaging must be added before relying on image recovery after reinstall.


## GitHub Actions build

The workflow is stored at `.github/workflows/build.yml` at the repository root.
It builds this project from the `LexiMemo/` subdirectory and uploads the debug APK
as the `LexiMemo-Debug-APK` artifact. The build uses Gradle 8.9 installed by
GitHub Actions, so a Gradle wrapper script is not required.
